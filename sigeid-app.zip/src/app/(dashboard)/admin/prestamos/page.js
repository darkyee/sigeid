export default function Prestamos() {
    return (
        <div>
            <h2>Este es Prestamos</h2>
        </div>
    )
}