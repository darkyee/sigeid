
import { redirect } from "next/navigation"

export default function HUD3() {

    redirect('/profesores/desperfectos')

    return ""
}