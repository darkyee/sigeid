export default function Inventario() {
    return (
        <div>
            <h2>Este es Inventario</h2>
        </div>
    )
}