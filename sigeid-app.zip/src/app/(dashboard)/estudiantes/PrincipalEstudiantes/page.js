export default function HUD2() {
    return (
        <div>
            <h2>Este es principal Estudiante</h2>
        </div>
    )
}